﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame
{
    class Menu
    {
        Playing playing = new Playing();
        string textMenu ="1.Начать игру " +
                        "\n2.Прочитать правила" +
                        "\n3.Выйти из игры";


        public void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("Добро пожаловать в игру " +
                "\nВыберите нужный пункт.");
            Console.WriteLine(textMenu);
            int choice = int.Parse(Console.ReadLine());
            DoPoint(choice);
        }
        public void DoPoint(int num)
        {
            switch (num)
            {
                case 1:
                    Console.WriteLine();
                    playing.PlayGame();
                    break;
                case 2:
                    Console.WriteLine();
                    Console.WriteLine("Правила игры" +
                                    "\nВы должны угадать какую следующую карту вытянет компьютер из перетасованной колоды, старшую или младшую" +
                                    "\nПеред этим нужно будет написать сколько ходов будет в игре и указать вашу ставку." +
                                    "\nЕсли вы смогли угадать карты на всех ходах, то ставка будет начисленна на ваш баланс, иначе" +
                                    "\nона будет списана с вашего счета." +
                                    "\nВ случае победы ваша ставка будет умножаться на коэффициент, который будет зависеть от количества ходов" +
                                    "\nКоэффициенты:" +
                                    "\nОт 1 до 3 ходов - коэффициент 1.5" +
                                    "\nОт 3 до 10 ходов - коэффициент 2" +
                                    "\nОт 10 и выше - коэффициент 5");
                    PrintMenu();
                    break;
                case 3:
                    Console.WriteLine();
                    Console.WriteLine("До свидания.");
                    break;
                default:
                    Console.WriteLine();
                    Console.WriteLine("Неправильно введены данные. Повторите еще раз");
                    break;
            }
        }
    }
}
