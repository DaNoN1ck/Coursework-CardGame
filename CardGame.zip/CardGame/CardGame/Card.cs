﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame //Представляет карту в колоде
{
    public enum Rank
    {
        Два, Три, Четыре, Пять, Шесть , Семь, Восесь, Девять, Десять, Валет, Королева, Король, Туз
    }
    public class Card
    {
        public Rank Rank { get; }
        public Card(Rank rank)
        {
            Rank = rank;
        }
    }
}
