﻿using System;

namespace CardGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();

            menu.PrintMenu();
        }
    }
}
