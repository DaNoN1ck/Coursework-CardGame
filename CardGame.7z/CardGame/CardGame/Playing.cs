﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame // Логика игры
{
    public class Playing
    {
        public void PlayGame(int balance = 100)
        {
            Computer computer = new Computer();

            int userBalance = balance; // Баланс игрока
            
            try
            {

                while (true)
                {
                    int step = 0;
                    Console.WriteLine("\nДобро пожаловать.");
                    Console.WriteLine($"На вашем балансе: {userBalance}");

                    Console.WriteLine("Выберите количество шагов в игре: ");
                    int userStep = int.Parse(Console.ReadLine()); //Кол-во шагов игрока
                    Console.WriteLine("\nСделайте ставку: ");
                    int bet = int.Parse(Console.ReadLine());//Ставка игрока

                    if (userBalance <= 0)
                    {
                        Console.WriteLine("На вашем счету недостаточно средств для продолжения игры." +
                            "\nВы не можете продолжать играть. Всего доброго.");
                        break;
                    }
                    if (bet > userBalance)
                    {
                        Console.WriteLine("Ваша ставка превышает ваш баланс. До свидания");
                        break;
                    }

                    Console.WriteLine("\nИгра началась");

                    while (true)
                    {
                        computer.Shuffle();//Перетасовка карт
                        Card card = computer.DrawCard();
                        Console.WriteLine($"\nЯ вытянул карту: {card.Rank}");

                        Console.WriteLine("Ставите на 'старшую' или 'младшую' карту?(с/м)");
                        string choice = Console.ReadLine().ToLower();

                        Card nextCard = computer.DrawCard();
                        Console.WriteLine($"Следующую я вытянул: {nextCard.Rank}");

                        bool correct = (choice == "с" && nextCard.Rank > card.Rank) ||
                                        (choice == "м" && nextCard.Rank < card.Rank);

                        if (correct)
                        {
                            Console.WriteLine("\nВы угадали. Идем дальше");
                            step++;
                        }
                        else
                        {
                            Console.WriteLine($"\nВы ошиблись. На {step +1} ходе");
                            Console.WriteLine("Я списываю ставку с вашего счета.");
                            userBalance -= bet;
                            break;
                        }

                        if (userStep == step)
                        {
                            bet = computer.CoefficientBet(userStep, bet);
                            userBalance += bet;
                            Console.WriteLine("\nПоздравляю!!!");
                            Console.WriteLine("Все ходы закончились и вы угадали все карты.");
                            Console.WriteLine("Я добавляю ставку вам на счет");
                            break;
                        }                       
                    }
                    Console.WriteLine($"\nВаш итоговый счет: {userBalance}");

                    Console.WriteLine("\nХотите продолжить игру? (да/нет)");
                    string playAgain = Console.ReadLine().ToLower();

                    if (playAgain == "нет")
                    {
                        Console.WriteLine("\nИгра завершена");
                        Console.WriteLine("Спасибо за игру! До свидания!");
                        break;
                    }
                }

            }
            catch
            {
                Console.WriteLine("Вы ввели некорректное значение");
                Console.WriteLine("Из-за вашей ошибки игра аварийно завершилась");
                Console.WriteLine($"\nВаш итоговый счет: {userBalance}");

            }       
        }
    }
}
