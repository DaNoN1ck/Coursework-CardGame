﻿using System;
using System.Collections.Generic;
using System.Text;
// Алгоритм тассования Фишера-Йетса https://allalgo.org/algorithm/21?lang=ru

namespace CardGame
{
    public class Computer //Создает колоду карт, перемешивает её и выдает
    {
        private List<Card> cards;
        private Random random;

        public Computer()
        {
            cards = new List<Card>();
            random = new Random();

            //создаем колоду карт
            foreach (Rank rank in Enum.GetValues(typeof(Rank))){
                cards.Add(new Card(rank));
            }
        }

        public void Shuffle()
        {
            //Перемешиваем колоду
            for (int i = cards.Count - 1; i >= 1; i--)
            {
                int j = random.Next(0, i + 1);

                Card temp = cards[i];
                cards[i] = cards[j];
                cards[j] = temp;
            }

        }

        public Card DrawCard()
        {
            //Выдаем верхнюю карту из колоды
            if (cards.Count > 0)
            {
                Card drawnCard = cards[0];
                cards.RemoveAt(0);
                return drawnCard;
            }
            else
            {
                throw new InvalidOperationException("Колода пуста");
            }
        }

        public int CoefficientBet(int step, int bet)
        {
            if(step > 0 && step <= 3)
            {
                bet = Convert.ToInt32(bet * 1.5);
            }
            else if(step > 3 && step <= 10)
            {
                bet = Convert.ToInt32(bet * 2);
            }
            else
            {
                bet = Convert.ToInt32(bet * 5);
            }
            return bet;
        }
    }

    

    
}
